/*package com.cards.poc;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class EventStoreMessageDeliveryApplicationTests {

	private RestTemplate restTemplate = new RestTemplate();

	@Test
	public void contextLoads() {

		testConsumer();
	}

	private void testConsumer() {

		String producedMessage = runProducer();

		String url = "http://10.217.100.253:5223/consumer/getMessage";

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> httpEntity = new HttpEntity<String>(headers);

		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, httpEntity, String.class);

		assertNotNull(response);
		assertEquals(producedMessage, response.getBody());
	}

	private String runProducer() {

		String url = "http://10.217.100.253:5223/producer/run";

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> httpEntity = new HttpEntity<String>(headers);

		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, httpEntity, String.class);

		if (response != null) {

			return response.getBody();
		}

		return "";
	}
}
*/