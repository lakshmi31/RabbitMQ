package com.cards.poc.conf;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.listener.SimpleMessageListenerContainer;
import org.springframework.amqp.rabbit.listener.adapter.MessageListenerAdapter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.backoff.ExponentialBackOff;

import com.cards.poc.messaging.Receiver;

@Configuration
public class RabbitMQConfiguration {

	private static final Logger LOG = LoggerFactory.getLogger(RabbitMQConfiguration.class);

	@Value("${spring.application.queue}")
	public static String QUEUE_NAME = "customer.default.queue";

	@Value("${spring.application.exchange}")
	public static String EXCHANGE_NAME = "customer.events.fanout.exchange";

	@Value("${spring.application.buffer.size}")
	public static Integer BUFFER_SIZE;

	@Bean
	Queue queue() {

		LOG.debug("Initializing queue object in bean method");

		return new Queue(QUEUE_NAME, true);
	}

	@Bean
	FanoutExchange exchange() {

		LOG.debug("Initializing FanoutExchange in bean method");

		return new FanoutExchange(EXCHANGE_NAME, true, false); // spring-boot-exchange
	}

	@Bean
	Binding binding() {

		LOG.debug("Initializing binding in bean method");

		return new Binding(QUEUE_NAME, Binding.DestinationType.QUEUE, EXCHANGE_NAME, "*.*", null);
	}

	@Bean
	public ConnectionFactory connectionFactory() {

		LOG.debug("Initializing ConnectionFactory object in bean method");

		CachingConnectionFactory connectionFactory = new CachingConnectionFactory("localhost");
		connectionFactory.setPublisherConfirms(true);

		return connectionFactory;
	}

	// If default error handling does not work, uncomment this and implement
	// ErrorHandler
	/*
	 * @Bean public SimpleRabbitListenerContainerFactory
	 * rabbitListenerContainerFactory() { SimpleRabbitListenerContainerFactory
	 * factory = new SimpleRabbitListenerContainerFactory();
	 * factory.setConnectionFactory(connectionFactory());
	 * factory.setErrorHandler(rabbitErrorHandler()); return factory; }
	 */

	@Bean
	SimpleMessageListenerContainer container(MessageListenerAdapter listenerAdapter) {

		LOG.debug("Initializing SimpleMessageListenerContainer object in bean method");

		SimpleMessageListenerContainer container = new SimpleMessageListenerContainer();
		container.setConnectionFactory(connectionFactory());
		container.setQueueNames(QUEUE_NAME);
		container.setMessageListener(listenerAdapter);
		container.setRecoveryBackOff(new ExponentialBackOff(1000, 1));
		return container;
	}

	@Bean
	MessageListenerAdapter listenerAdapter(Receiver receiver) {

		LOG.debug("Initializing listener adapter in bean method");

		return new MessageListenerAdapter(receiver, "receiveMessage");
	}
}
