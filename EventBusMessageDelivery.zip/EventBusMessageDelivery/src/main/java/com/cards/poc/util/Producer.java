package com.cards.poc.util;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cards.poc.conf.RabbitMQConfiguration;

/**
 * This class is for testing purpose only. This class acts as the Message
 * Producer for the RabbitMQ queue.
 *
 */
@Component
public class Producer {

	@Autowired
	private RabbitTemplate rabbitTemplate;

	/**
	 * Method to write the JSON string message in the RabbitMQ queue.
	 * 
	 * @param message
	 *            the input {@link String}
	 * @return {@link String} JSON message which is written on RabbitMQ queue
	 */
	public String produce(String message) {

		System.out.println("Sending message...");

		/*rabbitTemplate.setConfirmCallback(new RabbitTemplate.ConfirmCallback() {

			@Override
			public void confirm(CorrelationData correlationData, boolean b, String s) {

				System.out.println("confirmedMessage : " + correlationData.toString() + "  " + b + "  " + s);
			}
		});

		rabbitTemplate.setReturnCallback(new RabbitTemplate.ReturnCallback() {
			
			@Override
			public void returnedMessage(Message message, int i, String s, String s1, String s2) {
				System.out.println("Returned Message");

			}
		});
		
		rabbitTemplate.convertAndSend(RabbitMQConfiguration.EXCHANGE_NAME, "key", message, new CorrelationData("123"));*/

		rabbitTemplate.convertAndSend(RabbitMQConfiguration.QUEUE_NAME, message);

		return message;
	}

}