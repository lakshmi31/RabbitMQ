package com.cards.poc.messaging;

import java.io.IOException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CountDownLatch;

import org.springframework.amqp.core.MessageListener;
import org.springframework.stereotype.Component;

/**
 * This class is the RabbitMQ Message Listener and contains method to receive
 * and handle messages from RabbitMQ Queue
 *
 */
@Component
public class Receiver {

	private CountDownLatch latch = new CountDownLatch(1);

	/**
	 * This method is invoked automatically by {@link MessageListener} whenever
	 * there is new message in the queue. Then this method simply adds the
	 * received message in {@link BlockingQueue}, if there is space, otherwise
	 * waits till space is available
	 * 
	 * @param message
	 *            the message received from RabbitMQ queue
	 */
	public void receiveMessage(String message) {

		System.out.println("Received <" + message + ">");

		try {

			Buffer.messages.add(message);

		} catch (IllegalStateException queueFullException) {

			System.out.println("Queue is full... waiting");
		}

		latch.countDown();
	}

	public void handleMessage(Object customerAddedEvent) throws IOException, ClassNotFoundException {

		System.out.println("Received <" + customerAddedEvent.getClass() + ">");

		try {

			Buffer.messages.add(customerAddedEvent.toString());

		} catch (IllegalStateException queueFullException) {

			System.out.println("Queue is full... waiting");
		}

		latch.countDown();
	}

	public CountDownLatch getLatch() {

		return latch;
	}
}