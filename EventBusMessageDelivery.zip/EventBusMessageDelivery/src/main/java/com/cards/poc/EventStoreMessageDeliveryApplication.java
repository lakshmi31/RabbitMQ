package com.cards.poc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The main class of the application from where the application starts
 * 
 */
@SpringBootApplication
@EnableAutoConfiguration
public class EventStoreMessageDeliveryApplication {

	private static final Logger LOG = LoggerFactory.getLogger(EventStoreMessageDeliveryApplication.class);

	public static void main(String[] args) throws InterruptedException {

		LOG.info("Starting application");

		SpringApplication.run(EventStoreMessageDeliveryApplication.class, args);
	}
}