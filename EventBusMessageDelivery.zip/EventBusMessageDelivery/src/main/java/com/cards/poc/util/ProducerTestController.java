package com.cards.poc.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * REST Controller which contains REST API to insert a message into RabbitMQ
 * queue
 * 
 */
@Controller
@RequestMapping(value = "/producer")
public class ProducerTestController {

	@Autowired
	Producer producer;

	/**
	 * REST API to insert a message into RabbitMQ queue using the
	 * {@link Producer}
	 * 
	 * @return org.springframework.http.ResponseEntity<String>
	 */
	@RequestMapping(value = "/run", method = RequestMethod.GET)
	public ResponseEntity<String> runProducer() {

		Map<String, Object> object = new HashMap<String, Object>();
		object.put("firstName", "ABC");
		object.put("lastName", "XYZ");
		object.put("mobileNumber", "7534896598");
		object.put("emailAddress", "hello.world@gmail.com");

		Map<String, String> addressMap = new HashMap<String, String>();
		addressMap.put("buildingName", "building1");
		addressMap.put("streetName", "street1");
		addressMap.put("pincode", "123456");

		object.put("address", addressMap);
		object.put("dob", new Date());
		object.put("sourceIdentifier", "TCP");
		object.put("correlationID", "4f66350c-1741-42d9-9689-6ff0ab2b374e");

		System.out.println(JSONUtil.convertObjectToJSON(object));
		String jsonMessage = producer.produce(JSONUtil.convertObjectToJSON(object));

		return new ResponseEntity<String>(jsonMessage, HttpStatus.OK);
	}
}