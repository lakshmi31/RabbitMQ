package com.cards.poc.messaging;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

/**
 * This class has a {@link BlockingQueue} with a specific size. This size will
 * be dynamic from configuration. This {@link BlockingQueue} acts as a buffer
 * between the RabbitMQ Message Listener and the Camel Consumer
 *
 */
public class Buffer {

	public static BlockingQueue<String> messages = new ArrayBlockingQueue<String>(20, true);
}