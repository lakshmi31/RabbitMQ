package com.cards.poc.controllers;

import java.util.concurrent.BlockingQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cards.poc.messaging.Buffer;

/**
 * REST Controller for exposing the consumer APIs
 * 
 */
@Controller
@RequestMapping(value = "/consumer")
public class ConsumerController {

	private static final Logger LOG = LoggerFactory.getLogger(ConsumerController.class);

	/**
	 * REST API to get one message at a time from the {@link BlockingQueue}
	 * 
	 * @return org.springframework.http.ResponseEntity<String>
	 * 
	 */
	@RequestMapping(value = "/getMessage", method = RequestMethod.GET)
	public ResponseEntity<String> getMessage() {

		LOG.debug("Inside ConsumerController.getMessage() method");

		String message = "";

		if (Buffer.messages.size() != 0) {

			LOG.debug("Message found in Buffer. Returning message from ConsumerController.getMessage() method");

			message = Buffer.messages.poll();
			
			System.out.println("Dispatching message from consumer controller - " + message);

			LOG.debug("Message given to Camel - {}", message);

			return new ResponseEntity<String>(message, HttpStatus.OK);
		}

		LOG.debug("Buffer empty. Returning HTTP 204 status from ConsumerController.getMessage() method");

		return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
	}
}